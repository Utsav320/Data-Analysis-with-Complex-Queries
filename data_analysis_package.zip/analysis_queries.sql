-- 1. Revenue by Month using CTE
WITH monthly_revenue AS (
  SELECT DATE_TRUNC('month', order_date) AS month,
         SUM(total_amount) AS revenue
  FROM orders
  GROUP BY DATE_TRUNC('month', order_date)
)
SELECT * FROM monthly_revenue ORDER BY month;

-- 2. Top Customers using Subquery
SELECT name, total_spent FROM (
  SELECT u.name, SUM(o.total_amount) AS total_spent
  FROM users u
  JOIN orders o ON u.user_id = o.user_id
  GROUP BY u.name
) AS sub
ORDER BY total_spent DESC
LIMIT 5;

-- 3. Best-selling Product Category with Subquery
SELECT category, total_sales FROM (
  SELECT p.category, SUM(oi.quantity) AS total_sales
  FROM order_items oi
  JOIN products p ON oi.product_id = p.product_id
  GROUP BY p.category
) AS category_sales
ORDER BY total_sales DESC
LIMIT 1;

-- 4. Retention: Repeat Buyers using Window Function
SELECT user_id, order_id, order_date,
       COUNT(*) OVER (PARTITION BY user_id) AS total_orders_by_user
FROM orders
ORDER BY user_id;

-- 5. Month-over-Month Growth Rate using CTE and Window Function
WITH monthly_revenue AS (
  SELECT DATE_TRUNC('month', order_date) AS month,
         SUM(total_amount) AS revenue
  FROM orders
  GROUP BY DATE_TRUNC('month', order_date)
)
SELECT month,
       revenue,
       LAG(revenue) OVER (ORDER BY month) AS previous_revenue,
       ROUND(
         (revenue - LAG(revenue) OVER (ORDER BY month)) /
         NULLIF(LAG(revenue) OVER (ORDER BY month), 0) * 100, 2
       ) AS growth_percentage
FROM monthly_revenue;