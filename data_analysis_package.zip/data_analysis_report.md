# 📊 Advanced SQL Data Analysis Report – CODTECH Internship

## 1. Monthly Revenue (CTE)
- **What it does:** Aggregates total revenue per month.
- **Why it matters:** Identifies high/low earning months, helps budget forecasting.

## 2. Top 5 Customers (Subquery)
- **What it does:** Calculates and ranks customers by total spend.
- **Why it matters:** Highlights key users for rewards or marketing.

## 3. Best-Selling Category (Subquery)
- **What it does:** Finds the most purchased product category.
- **Why it matters:** Guides inventory and promotion strategy.

## 4. Repeat Buyers (Window Function)
- **What it does:** Counts orders per user using a window function.
- **Why it matters:** Identifies loyal customers for retention analysis.

## 5. Revenue Growth Rate (CTE + Window Function)
- **What it does:** Shows month-over-month revenue growth percentage.
- **Why it matters:** Tracks business growth, trends, and downturns.

---

*Prepared by: [Your Name]*  
*Date: 2025-06-15*